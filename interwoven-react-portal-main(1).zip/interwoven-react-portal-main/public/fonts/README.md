
# Open Sans Font Files

To make this application work offline, you need to download the following font files and place them in this directory:

1. **open-sans-light.woff2** (300 weight)
   - Download from: https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTUGmu0SC55K5gw.woff2

2. **open-sans-regular.woff2** (400 weight)
   - Download from: https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2

3. **open-sans-medium.woff2** (500 weight)
   - Download from: https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVZbX2vVnXBbObj2OVTSGmu0SC55I.woff2

4. **open-sans-semibold.woff2** (600 weight)
   - Download from: https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55I.woff2

5. **open-sans-bold.woff2** (700 weight)
   - Download from: https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTiGmu0SC55I.woff2

## Instructions:
1. Create this `public/fonts/` directory if it doesn't exist
2. Download each .woff2 file from the URLs above
3. Save them with the exact filenames listed above
4. The CSS file (`open-sans.css`) is already configured to reference these local files

## Verification:
After placing the font files, you can verify they're working by:
1. Opening browser developer tools
2. Going to Network tab
3. Refreshing the page
4. Check that font files are loaded from local sources (not external URLs)
