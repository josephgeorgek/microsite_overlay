package com.bank.regional.controller;

import com.bank.regional.model.ContentResponse;
import com.bank.regional.services.ContentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ContentController.class)
public class ContentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ContentService contentService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void getBanner_ValidCountryAndLanguage_ReturnsContent() throws Exception {
        ContentResponse mockResponse = new ContentResponse(
                "Welcome to Business Banking",
                "Secure and reliable banking services",
                null,
                "banner content"
        );

        when(contentService.getBanner("sg", "en")).thenReturn(mockResponse);

        mockMvc.perform(get("/digital-content/sg/business/web/en/bfo/common/banner/banner_content.json"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.title").value("Welcome to Business Banking"))
                .andExpect(jsonPath("$.subtitle").value("Secure and reliable banking services"));
    }

    @Test
    public void getBackgroundImage_ValidCountryAndLanguage_ReturnsImageUrl() throws Exception {
        ContentResponse mockResponse = new ContentResponse(
                null,
                null,
                "/sg-background.jpg",
                null
        );

        when(contentService.getBackgroundImage("sg", "en")).thenReturn(mockResponse);

        mockMvc.perform(get("/digital-content/sg/business/web/en/bfo/common/background/background_image.json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.backgroundUrl").value("/sg-background.jpg"));
    }

    @Test
    public void getAnnouncement_ValidCountryAndLanguage_ReturnsAnnouncement() throws Exception {
        String mockAnnouncement = "Security notice: Stay vigilant against fraudulent activities.";

        when(contentService.getAnnouncement("sg", "en")).thenReturn(mockAnnouncement);

        mockMvc.perform(get("/digital-content/sg/business/web/en/bfo/common/announcement/announcement.json"))
                .andExpect(status().isOk())
                .andExpect(content().string("\"" + mockAnnouncement + "\""));
    }

    @Test
    public void getBanner_ChineseLanguage_ReturnsChineseContent() throws Exception {
        ContentResponse mockResponse = new ContentResponse(
                "欢迎使用企业银行",
                "安全可靠的银行服务",
                null,
                "横幅内容"
        );

        when(contentService.getBanner("sg", "zh")).thenReturn(mockResponse);

        mockMvc.perform(get("/digital-content/sg/business/web/zh/bfo/common/banner/banner_content.json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("欢迎使用企业银行"))
                .andExpect(jsonPath("$.subtitle").value("安全可靠的银行服务"));
    }

    @Test
    public void getContent_AllSupportedCountries_ReturnsContent() throws Exception {
        String[] countries = {"sg", "my", "hk", "id", "cn", "vn", "th"};
        
        for (String country : countries) {
            ContentResponse mockResponse = new ContentResponse(
                    "Welcome to Business Banking",
                    "Secure and reliable banking services",
                    null,
                    "content for " + country
            );

            when(contentService.getBanner(country, "en")).thenReturn(mockResponse);

            mockMvc.perform(get("/digital-content/" + country + "/business/web/en/bfo/common/banner/banner_content.json"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.title").value("Welcome to Business Banking"));
        }
    }

    @Test
    public void getContent_InvalidCountry_StillReturnsContent() throws Exception {
        ContentResponse mockResponse = new ContentResponse(
                "Welcome to Business Banking",
                "Secure and reliable banking services",
                null,
                "default content"
        );

        when(contentService.getBanner("invalid", "en")).thenReturn(mockResponse);

        mockMvc.perform(get("/digital-content/invalid/business/web/en/bfo/common/banner/banner_content.json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Welcome to Business Banking"));
    }
}
