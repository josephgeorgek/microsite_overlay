package com.bank.regional.service;

import com.bank.regional.entity.ContentData;
import com.bank.regional.model.ContentResponse;
import com.bank.regional.repository.ContentDataRepository;
import com.bank.regional.services.imp.ContentServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ContentServiceTest {

    @Mock
    private ContentDataRepository contentDataRepository;

    @InjectMocks
    private ContentServiceImpl contentService;

    private ContentData bannerContent;
    private ContentData backgroundContent;
    private ContentData announcementContent;

    @BeforeEach
    void setUp() {
        bannerContent = new ContentData();
        bannerContent.setId(1L);
        bannerContent.setCountry("SG");
        bannerContent.setLanguage("en");
        bannerContent.setContentType("banner");
        bannerContent.setContentData("Welcome to Business Banking");

        backgroundContent = new ContentData();
        backgroundContent.setId(2L);
        backgroundContent.setCountry("SG");
        backgroundContent.setLanguage("en");
        backgroundContent.setContentType("background");
        backgroundContent.setBackgroundUrl("/sg-background.jpg");

        announcementContent = new ContentData();
        announcementContent.setId(3L);
        announcementContent.setCountry("SG");
        announcementContent.setLanguage("en");
        announcementContent.setContentType("announcement");
        announcementContent.setContentData("Security notice: Stay vigilant against fraudulent activities.");
    }

    @Test
    void getBanner_EnglishContent_ReturnsEnglishBanner() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("SG", "en", "banner"))
                .thenReturn(Optional.of(bannerContent));

        // Act
        ContentResponse response = contentService.getBanner("SG", "en");

        // Assert
        assertEquals("Welcome to Business Banking", response.getTitle());
        assertEquals("Secure and reliable banking services", response.getSubtitle());
        assertEquals("Welcome to Business Banking", response.getContent());
    }

    @Test
    void getBanner_ChineseContent_ReturnsChineseBanner() {
        // Arrange
        ContentData chineseBanner = new ContentData();
        chineseBanner.setContentData("欢迎使用企业银行");
        when(contentDataRepository.findByCountryAndLanguageAndContentType("SG", "zh", "banner"))
                .thenReturn(Optional.of(chineseBanner));

        // Act
        ContentResponse response = contentService.getBanner("SG", "zh");

        // Assert
        assertEquals("欢迎使用企业银行", response.getTitle());
        assertEquals("安全可靠的银行服务", response.getSubtitle());
        assertEquals("欢迎使用企业银行", response.getContent());
    }

    @Test
    void getBanner_NoContentFound_ReturnsDefaultBanner() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("XX", "en", "banner"))
                .thenReturn(Optional.empty());

        // Act
        ContentResponse response = contentService.getBanner("XX", "en");

        // Assert
        assertEquals("Welcome to Business Banking", response.getTitle());
        assertEquals("Secure and reliable banking services", response.getSubtitle());
        assertNull(response.getContent());
    }

    @Test
    void getBackgroundImage_ContentExists_ReturnsBackgroundUrl() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("SG", "en", "background"))
                .thenReturn(Optional.of(backgroundContent));

        // Act
        ContentResponse response = contentService.getBackgroundImage("SG", "en");

        // Assert
        assertEquals("/sg-background.jpg", response.getBackgroundUrl());
    }

    @Test
    void getBackgroundImage_NoContentFound_ReturnsDefaultBackground() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("XX", "en", "background"))
                .thenReturn(Optional.empty());

        // Act
        ContentResponse response = contentService.getBackgroundImage("XX", "en");

        // Assert
        assertEquals("/default-background.jpg", response.getBackgroundUrl());
    }

    @Test
    void getAnnouncement_EnglishContent_ReturnsEnglishAnnouncement() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("SG", "en", "announcement"))
                .thenReturn(Optional.of(announcementContent));

        // Act
        String announcement = contentService.getAnnouncement("SG", "en");

        // Assert
        assertEquals("Security notice: Stay vigilant against fraudulent activities.", announcement);
    }

    @Test
    void getAnnouncement_ChineseContent_ReturnsChineseAnnouncement() {
        // Arrange
        ContentData chineseAnnouncement = new ContentData();
        chineseAnnouncement.setContentData("安全提醒：保持警惕，防范欺诈活动。");
        when(contentDataRepository.findByCountryAndLanguageAndContentType("SG", "zh", "announcement"))
                .thenReturn(Optional.of(chineseAnnouncement));

        // Act
        String announcement = contentService.getAnnouncement("SG", "zh");

        // Assert
        assertEquals("安全提醒：保持警惕，防范欺诈活动。", announcement);
    }

    @Test
    void getAnnouncement_NoContentFound_ReturnsDefaultAnnouncement() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("XX", "en", "announcement"))
                .thenReturn(Optional.empty());

        // Act
        String announcement = contentService.getAnnouncement("XX", "en");

        // Assert
        assertTrue(announcement.contains("Security notice"));
        assertTrue(announcement.contains("fraudulent activities"));
    }

    @Test
    void getAnnouncement_NoContentFoundChinese_ReturnsDefaultChineseAnnouncement() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("XX", "zh", "announcement"))
                .thenReturn(Optional.empty());

        // Act
        String announcement = contentService.getAnnouncement("XX", "zh");

        // Assert
        assertTrue(announcement.contains("安全提醒"));
        assertTrue(announcement.contains("欺诈活动"));
    }

    @Test
    void getBanner_MalaysiaContent_ReturnsMalaysianBanner() {
        // Arrange
        ContentData malaysiaBanner = new ContentData();
        malaysiaBanner.setCountry("MY");
        malaysiaBanner.setContentData("Welcome to Malaysian Business Banking");
        when(contentDataRepository.findByCountryAndLanguageAndContentType("MY", "en", "banner"))
                .thenReturn(Optional.of(malaysiaBanner));

        // Act
        ContentResponse response = contentService.getBanner("MY", "en");

        // Assert
        assertEquals("Welcome to Malaysian Business Banking", response.getContent());
    }

    @Test
    void getBackgroundImage_HongKongContent_ReturnsHongKongBackground() {
        // Arrange
        ContentData hkBackground = new ContentData();
        hkBackground.setBackgroundUrl("/hk-skyline.jpg");
        when(contentDataRepository.findByCountryAndLanguageAndContentType("HK", "en", "background"))
                .thenReturn(Optional.of(hkBackground));

        // Act
        ContentResponse response = contentService.getBackgroundImage("HK", "en");

        // Assert
        assertEquals("/hk-skyline.jpg", response.getBackgroundUrl());
    }

    @Test
    void getAnnouncement_IndonesiaContent_ReturnsIndonesianAnnouncement() {
        // Arrange
        ContentData indonesiaAnnouncement = new ContentData();
        indonesiaAnnouncement.setContentData("Pemberitahuan keamanan: Tetap waspada terhadap aktivitas penipuan.");
        when(contentDataRepository.findByCountryAndLanguageAndContentType("ID", "en", "announcement"))
                .thenReturn(Optional.of(indonesiaAnnouncement));

        // Act
        String announcement = contentService.getAnnouncement("ID", "en");

        // Assert
        assertEquals("Pemberitahuan keamanan: Tetap waspada terhadap aktivitas penipuan.", announcement);
    }

    @Test
    void getContent_AllCountriesSupported_HandlesCorrectly() {
        String[] countries = {"SG", "MY", "HK", "ID", "CN", "VN", "TH"};
        
        for (String country : countries) {
            // Test banner for each country
            when(contentDataRepository.findByCountryAndLanguageAndContentType(country, "en", "banner"))
                    .thenReturn(Optional.empty());
            
            ContentResponse response = contentService.getBanner(country, "en");
            assertNotNull(response);
            assertEquals("Welcome to Business Banking", response.getTitle());
        }
    }

    @Test
    void getContent_InvalidCountryCode_HandlesGracefully() {
        // Arrange
        when(contentDataRepository.findByCountryAndLanguageAndContentType("INVALID", "en", "banner"))
                .thenReturn(Optional.empty());

        // Act
        ContentResponse response = contentService.getBanner("INVALID", "en");

        // Assert
        assertNotNull(response);
        assertEquals("Welcome to Business Banking", response.getTitle());
    }
}
