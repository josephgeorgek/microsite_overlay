
-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    organization_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    country VARCHAR(5) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    blocked BOOLEAN NOT NULL DEFAULT FALSE
);

-- Create content_data table
CREATE TABLE IF NOT EXISTS content_data (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    country VARCHAR(5) NOT NULL,
    language VARCHAR(5) NOT NULL,
    content_type VARCHAR(20) NOT NULL,
    content_data TEXT,
    background_url VARCHAR(500)
);
