
package com.bank.regional.services;

import com.bank.regional.model.ContentResponse;

public interface ContentService {
    ContentResponse getBanner(String country, String language);
    ContentResponse getBackgroundImage(String country, String language);
    String getAnnouncement(String country, String language);
}
