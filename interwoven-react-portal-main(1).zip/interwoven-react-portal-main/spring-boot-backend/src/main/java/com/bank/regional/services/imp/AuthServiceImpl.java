package com.bank.regional.services.imp;

import com.bank.regional.entity.User;
import com.bank.regional.model.LoginRequest;
import com.bank.regional.model.LoginResponse;
import com.bank.regional.repository.UserRepository;
import com.bank.regional.services.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthServiceImpl implements AuthService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Override
    public LoginResponse authenticate(LoginRequest request, String country) {
        Optional<User> user = userRepository.findByOrganizationIdAndUserIdAndCountry(
                request.getOrganisationId(), 
                request.getUserId(), 
                country.toUpperCase()
        );
        
        if (user.isPresent()) {
            User foundUser = user.get();
            
            // Check if user is blocked
            if (foundUser.getBlocked()) {
                return new LoginResponse(false, "User is blocked", null, country);
            }
            
            if (foundUser.getPassword().equals(request.getPassword())) {
                return new LoginResponse(true, "Login successful", "mock-jwt-token", country);
            } else {
                return new LoginResponse(false, "Invalid credentials", null, country);
            }
        } else {
            return new LoginResponse(false, "Invalid credentials", null, country);
        }
    }
    
    @Override
    public LoginResponse blockUser(LoginRequest request, String country) {
        Optional<User> user = userRepository.findByOrganizationIdAndUserIdAndCountry(
                request.getOrganisationId(), 
                request.getUserId(), 
                country.toUpperCase()
        );
        
        if (user.isPresent() && user.get().getPassword().equals(request.getPassword())) {
            User foundUser = user.get();
            foundUser.setBlocked(true);
            userRepository.save(foundUser);
            return new LoginResponse(true, "User blocked successfully", null, country);
        } else {
            return new LoginResponse(false, "User not found", null, country);
        }
    }
    
    @Override
    public LoginResponse resetPassword(String organizationId, String userId, String country) {
        Optional<User> user = userRepository.findByOrganizationIdAndUserIdAndCountry(
                organizationId, userId, country.toUpperCase()
        );
        
        if (user.isPresent()) {
            return new LoginResponse(true, "Password reset initiated", null, country);
        } else {
            return new LoginResponse(false, "User not found", null, country);
        }
    }
    
    @Override
    public LoginResponse activateUser(String organizationId, String userId, String country) {
        Optional<User> user = userRepository.findByOrganizationIdAndUserIdAndCountry(
                organizationId, userId, country.toUpperCase()
        );
        
        if (user.isPresent()) {
            return new LoginResponse(true, "User activation initiated", null, country);
        } else {
            return new LoginResponse(false, "User not found", null, country);
        }
    }
}
