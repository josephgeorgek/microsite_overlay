package com.bank.regional.controller;

import com.bank.regional.model.LoginRequest;
import com.bank.regional.model.LoginResponse;
import com.bank.regional.services.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@Tag(name = "Authentication", description = "Authentication APIs for corporate banking")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Operation(summary = "Corporate User Login", description = "Authenticate corporate users with organization ID, user ID, and password")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Login successful", 
                        content = @Content(mediaType = "application/json", schema = @Schema(implementation = LoginResponse.class))),
            @ApiResponse(responseCode = "401", description = "Invalid credentials", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping("/{country}/customer-security-corp/v1/orguserid-login")
    public ResponseEntity<LoginResponse> login(
            @Parameter(description = "Country code (sg, my, hk, id, cn, vn, th)", example = "sg") 
            @PathVariable String country,
            @RequestBody LoginRequest loginRequest) {
        
        LoginResponse response = authService.authenticate(loginRequest, country);
        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body(response);
        }
    }

    @Operation(summary = "Block User Access", description = "Block user access to accounts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User blocked successfully", content = @Content),
            @ApiResponse(responseCode = "400", description = "User not found", content = @Content)
    })
    @PostMapping("/{country}/customer-security-corp/v1/block-access")
    public ResponseEntity<Map<String, String>> blockAccess(
            @Parameter(description = "Country code (sg, my, hk, id, cn, vn, th)", example = "sg") 
            @PathVariable String country,
            @RequestBody LoginRequest blockRequest) {
        
        LoginResponse response = authService.blockUser(blockRequest, country);
        
        if (response.isSuccess()) {
            Map<String, String> result = Map.of(
                    "status", "success",
                    "message", "Your account is blocked with immediate effect"
            );
            return ResponseEntity.ok(result);
        } else {
            Map<String, String> result = Map.of(
                    "errorCode", "ACLCORP-1018",
                    "description", "Unable to get User Session Corporate"
            );
            return ResponseEntity.status(400).body(result);
        }
    }

    @Operation(summary = "Password Reset", description = "Initiate password reset for corporate users")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Password reset initiated successfully", content = @Content),
            @ApiResponse(responseCode = "404", description = "User not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping("/{country}/customer-security-corp/v1/password-reset")
    public ResponseEntity<Map<String, String>> resetPassword(
            @Parameter(description = "Country code (sg, my, hk, id, cn, vn, th)", example = "sg") 
            @PathVariable String country,
            @RequestBody Map<String, String> request) {
        
        String organizationId = request.get("organizationId");
        String userId = request.get("userId");
        
        LoginResponse response = authService.resetPassword(organizationId, userId, country);
        
        Map<String, String> result = Map.of(
                "status", response.isSuccess() ? "success" : "failed",
                "message", response.getMessage()
        );
        
        return response.isSuccess() ? ResponseEntity.ok(result) : ResponseEntity.status(404).body(result);
    }

    @Operation(summary = "User Activation", description = "Activate new corporate user accounts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User activation initiated successfully", content = @Content),
            @ApiResponse(responseCode = "404", description = "User not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping("/{country}/customer-security-corp/v1/user-activation")
    public ResponseEntity<Map<String, String>> activateUser(
            @Parameter(description = "Country code (sg, my, hk, id, cn, vn, th)", example = "sg") 
            @PathVariable String country,
            @RequestBody Map<String, String> request) {
        
        String organizationId = request.get("organizationId");
        String userId = request.get("userId");
        
        LoginResponse response = authService.activateUser(organizationId, userId, country);
        
        Map<String, String> result = Map.of(
                "status", response.isSuccess() ? "success" : "failed",
                "message", response.getMessage()
        );
        
        return response.isSuccess() ? ResponseEntity.ok(result) : ResponseEntity.status(404).body(result);
    }
}
