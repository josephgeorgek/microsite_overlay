
package com.bank.regional.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "content_data")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ContentData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "country", nullable = false)
    private String country;
    
    @Column(name = "language", nullable = false)
    private String language;
    
    @Column(name = "content_type", nullable = false)
    private String contentType; // 'banner', 'background', 'announcement'
    
    @Column(name = "content_data", columnDefinition = "TEXT")
    private String contentData;
    
    @Column(name = "background_url")
    private String backgroundUrl;
}
