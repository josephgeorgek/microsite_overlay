
package com.bank.regional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegionalBankApplication {
    public static void main(String[] args) {
        SpringApplication.run(RegionalBankApplication.class, args);
    }
}
