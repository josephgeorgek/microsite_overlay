
package com.bank.regional.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "organization_id", nullable = false)
    private String organizationId;
    
    @Column(name = "user_id", nullable = false)
    private String userId;
    
    @Column(name = "password", nullable = false)
    private String password;
    
    @Column(name = "country", nullable = false)
    private String country;
    
    @Column(name = "active", nullable = false)
    private Boolean active = true;
    
    @Column(name = "blocked", nullable = false)
    private Boolean blocked = false;
}
