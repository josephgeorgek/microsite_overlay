
package com.bank.regional.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContentResponse {
    private String title;
    private String subtitle;
    private String backgroundUrl;
    private String content;
}
