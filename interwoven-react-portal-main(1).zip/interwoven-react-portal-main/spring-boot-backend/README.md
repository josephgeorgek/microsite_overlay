
# Regional Bank Backend

This is a Spring Boot backend application for the Regional Bank system that supports multiple countries and languages.

## Features

- Multi-country support (SG, MY, HK, ID, CN, VN, TH)
- Multi-language support (English, Chinese)
- Country-specific content delivery
- User authentication and management
- H2 in-memory database with test data
- **Swagger/OpenAPI 3.0 Documentation**

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher

## Running the Application

1. Navigate to the spring-boot-backend directory:
   ```bash
   cd spring-boot-backend
   ```

2. Run the application:
   ```bash
   mvn spring-boot:run
   ```

3. The application will start on http://localhost:8080

## API Documentation

### Swagger UI
Access the interactive API documentation at:
- **Swagger UI**: http://localhost:8080/swagger-ui/index.html
- **OpenAPI JSON**: http://localhost:8080/v3/api-docs
- **OpenAPI YAML**: http://localhost:8080/v3/api-docs.yaml

The Swagger documentation includes:
- Complete API endpoint descriptions
- Request/response schemas
- Interactive testing capabilities
- Example requests and responses

## Database

The application uses H2 in-memory database. You can access the H2 console at:
- URL: http://localhost:8080/h2-console
- JDBC URL: jdbc:h2:mem:testdb
- Username: sa
- Password: password

## Test Data

The application includes test users for each country:

### Singapore (SG)
- ACME001/JOHNDOE/password123
- CORP002/JANESMITH/password456

### Malaysia (MY)
- ACME001/AHMAD/password123
- CORP002/SITI/password456

### Hong Kong (HK)
- ACME001/WONG/password123
- CORP002/CHAN/password456

### Indonesia (ID)
- ACME001/BUDI/password123
- CORP002/SARI/password456

### China (CN)
- ACME001/ZHANG/password123
- CORP002/LI/password456

### Vietnam (VN)
- ACME001/NGUYEN/password123
- CORP002/TRAN/password456

### Thailand (TH)
- ACME001/SOMCHAI/password123
- CORP002/MALEE/password456

## API Endpoints

### Authentication
- POST /{country}/customer-security-corp/v1/orguserid-login
- POST /{country}/customer-security-corp/v1/password-reset
- POST /{country}/customer-security-corp/v1/user-activation

### Content
- GET /{country}/business/web/{language}/bfo/common/banner/banner_content.json
- GET /{country}/business/web/{language}/bfo/common/images/background_image.json
- GET /{country}/business/web/{language}/bfo/prelogin/announcement/microsites/microsite_announcement.html

## Running Tests

```bash
mvn test
```

## CORS Configuration

The application includes CORS configuration to allow requests from the frontend application running on different ports.

## Development Tools

- **Postman Collection**: Import `Regional-Bank-API.postman_collection.json` for API testing
- **Swagger UI**: Interactive API documentation and testing
- **H2 Console**: Database inspection and query execution
