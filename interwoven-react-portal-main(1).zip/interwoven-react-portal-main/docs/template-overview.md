
# Regional Bank Business Banking Login - Lovable Template

## Template Overview

This template provides a complete business banking login application with multi-country and multi-language support, built with React, TypeScript, and Spring Boot backend.

## Key Features

### 🌍 Multi-Country Support
- Singapore (SG), Malaysia (MY), Hong Kong (HK)
- Indonesia (ID), China (CN), Vietnam (VN), Thailand (TH)

### 🗣️ Multi-Language Support
- English (EN) and Chinese (ZH)

### 🔐 Authentication Features
- Organization-based login
- User credential validation
- Account blocking functionality
- Password reset workflow
- New user activation

### 🎨 UI/UX Features
- Responsive design (mobile to desktop)
- Dynamic background images
- Localized announcements
- Interactive help system
- Progress indicators
- Accessibility compliant

### 🛠️ Technical Features
- RESTful API backend
- H2 in-memory database
- Dynamic content loading
- CORS enabled
- Swagger API documentation
- Comprehensive error handling

## Use Case

This template is ideal for:
- Financial institutions requiring multi-country support
- Applications needing organization-based authentication
- Projects requiring dynamic content management
- Systems with complex fallback mechanisms
- Applications needing comprehensive documentation

## Browser Support

- Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

## License

This template is provided for educational and development purposes.
