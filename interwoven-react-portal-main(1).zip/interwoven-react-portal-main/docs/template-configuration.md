# Configuration Guide - Lovable Template

## Frontend Configuration

### 1. Environment Variables (.env)
```env
# API Configuration
VITE_API_BASE_URL=http://localhost:8080
VITE_APP_NAME=Regional Bank Portal
VITE_APP_VERSION=1.0.0

# Feature Flags
VITE_ENABLE_DEBUG=true
VITE_ENABLE_ANALYTICS=false
```

### 2. Application Configuration (src/config/AppConfig.ts)
```typescript
// Background Images
static updateBackgroundConfig(newConfig: BackgroundConfig) {
  this.backgroundConfig = { ...this.backgroundConfig, ...newConfig };
}

// Security Settings
private static securityNoticeConfig = {
  announcementUrl: 'https://your-announcements.com/api',
  fallbackNotice: {
    en: 'Security advisory message...',
    zh: '安全提醒消息...'
  }
};
```

### 3. Service Configuration (src/services/ConfigService.ts)
```typescript
// External Links
static updateLinks(newLinks: Partial<ConfigLinks>) {
  this.links = { ...this.links, ...newLinks };
}

// Country-specific Contact Info
static addCountryContact(country: string, contact: ContactInfo) {
  this.contactInfo[country.toLowerCase()] = contact;
}
```

## Backend Configuration

### 1. Database Configuration (application.properties)
```properties
# H2 Development Database
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.username=sa
spring.datasource.password=password

# PostgreSQL Production (uncomment when ready)
# spring.datasource.url=jdbc:postgresql://localhost:5432/regionalbank
# spring.datasource.username=your_username
# spring.datasource.password=your_password
# spring.datasource.driver-class-name=org.postgresql.Driver
```

### 2. Server Configuration
```properties
# Server Settings
server.port=8080
server.servlet.context-path=/

# SSL Configuration (for production)
# server.ssl.enabled=true
# server.ssl.key-store=classpath:keystore.p12
# server.ssl.key-store-password=your_password
```

### 3. CORS Configuration (CorsConfig.java)
```java
@Configuration
public class CorsConfig {
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                    .allowedOrigins("http://localhost:5173", "https://yourapp.com")
                    .allowedMethods("*")
                    .allowedHeaders("*");
            }
        };
    }
}
```

## Customization Examples

### Adding New Country Support
```typescript
// 1. Add to country selector
const countries = [
  // existing countries...
  { code: 'ph', name: 'Philippines', flag: '🇵🇭' }
];

// 2. Add contact information
ConfigService.addCountryContact('ph', {
  phone: '+63 2 888 1234',
  hours: 'Mon to Fri | 9:00AM - 6:00PM'
});

// 3. Add test users to database
INSERT INTO users VALUES (25, 'ACME001', 'JUAN', 'password123', 'PH', true, false);
```

### Changing Branding
```typescript
// Update logo and colors in BankLogo.tsx
const bankConfig = {
  name: 'Your Bank Name',
  logo: '/path/to/your/logo.png',
  primaryColor: '#your-color',
  secondaryColor: '#your-secondary-color'
};
```

### Environment-Specific Settings
```properties
# application-dev.properties
spring.jpa.show-sql=true
logging.level.com.bank.regional=DEBUG

# application-prod.properties  
spring.jpa.show-sql=false
logging.level.com.bank.regional=WARN
spring.datasource.url=jdbc:postgresql://prod-server:5432/regionalbank
```

## Security Configuration

### JWT Settings
```properties
# JWT Configuration
jwt.secret=your-secret-key
jwt.expiration=86400000
```

### Password Policy
```properties
# Password Requirements
password.min.length=8
password.require.uppercase=true
password.require.numbers=true
password.require.special=true
```

## Monitoring and Logging

### Application Metrics
```properties
# Actuator Configuration
management.endpoints.web.exposure.include=health,info,metrics
management.endpoint.health.show-details=always
```

### Logging Configuration
```properties
# Logging Levels
logging.level.com.bank.regional=INFO
logging.level.org.springframework.web=DEBUG
logging.pattern.file=%d{yyyy-MM-dd HH:mm:ss} - %msg%n
```
