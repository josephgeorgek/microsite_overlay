
# Frontend Component Specifications - Regional Bank Application

## Architecture Overview

The application follows a modular component architecture with clear separation of concerns:

- **Pages**: Route-level components (`src/pages/`)
- **Components**: Reusable UI components (`src/components/`)
- **Services**: API and business logic (`src/services/`)
- **Utils**: Helper functions (`src/utils/`)
- **UI Components**: Shadcn/UI components (`src/components/ui/`)

## Component Hierarchy

```
App
├── Index (Main Page)
│   ├── BankLogo
│   ├── CountrySelector
│   ├── LanguageToggle
│   ├── NeedHelpDialog
│   │   └── BlockAccessDialog
│   ├── NewUserWizard
│   └── ResetPasswordWizard
└── NotFound
```

## Core Components

### 1. Index Page (`src/pages/Index.tsx`)
**Purpose**: Main login page and application entry point
**Size**: 297 lines (Needs refactoring)
**Responsibilities**:
- User authentication form
- Country and language selection
- Content loading and display
- Wizard and dialog management

**Props**: None (root component)
**State Management**:
- Form inputs (organizationId, userId, password)
- UI state (showPassword, loading states)
- Content state (announcement, banner, background)
- Dialog visibility states

**Integration Points**:
- AuthService for login
- ContentService for dynamic content
- StorageUtils for persistence
- Multiple child components for UI

**Reusability**: Low (page-level component)

### 2. BankLogo (`src/components/BankLogo.tsx`)
**Purpose**: Display bank branding
**Responsibilities**:
- Render bank logo with proper styling
- Provide consistent branding across application

**Props**: None
**Reusability**: High (used across multiple pages)
**Integration**: Standalone component

### 3. CountrySelector (`src/components/CountrySelector.tsx`)
**Purpose**: Country selection dropdown
**Responsibilities**:
- Display available countries
- Handle country selection
- Show country flags and names

**Props**:
- `value: string` - Current selected country
- `onChange: (country: string) => void` - Selection handler

**Reusability**: High (can be used in multiple contexts)
**Integration**: Integrated with storage utils for persistence

### 4. LanguageToggle (`src/components/LanguageToggle.tsx`)
**Purpose**: Language switching interface
**Responsibilities**:
- Toggle between English and Chinese
- Provide visual language indicators

**Props**:
- `value: string` - Current language
- `onChange: (language: string) => void` - Change handler

**Reusability**: High (language switching needed globally)
**Integration**: Affects all localized content

### 5. NeedHelpDialog (`src/components/NeedHelpDialog.tsx`)
**Purpose**: Help and support interface
**Responsibilities**:
- Fraud reporting with contact information
- FAQ links with external redirects
- Block access functionality

**Props**:
- `open: boolean` - Dialog visibility
- `onClose: () => void` - Close handler
- `language: string` - Current language for localization
- `country: string` - Country for contact info

**State Management**:
- Expandable sections
- Contact info visibility

**Child Components**:
- BlockAccessDialog

**Reusability**: Medium (help functionality specific but patterns reusable)

### 6. BlockAccessDialog (`src/components/BlockAccessDialog.tsx`)
**Purpose**: Account blocking interface
**Responsibilities**:
- Account blocking form
- Validation and submission
- Success/error handling

**Props**:
- `open: boolean` - Dialog visibility
- `onClose: () => void` - Close handler
- `language: string` - Localization

**Integration Points**:
- ConfigService for endpoint URLs
- Form validation
- API calls for blocking

**Reusability**: Low (specific functionality)

### 7. NewUserWizard (`src/components/NewUserWizard.tsx`)
**Purpose**: New user activation flow
**Responsibilities**:
- Multi-step user activation
- Form validation
- Progress indication

**Props**:
- `open: boolean` - Wizard visibility
- `onClose: () => void` - Close handler
- `language: string` - Localization

**Reusability**: Low (specific workflow)

### 8. ResetPasswordWizard (`src/components/ResetPasswordWizard.tsx`)
**Purpose**: Password reset workflow
**Responsibilities**:
- Password reset steps
- Email/SMS verification
- Progress tracking

**Props**:
- `open: boolean` - Wizard visibility
- `onClose: () => void` - Close handler
- `language: string` - Localization

**Reusability**: Low (specific workflow)

## Service Layer

### 1. AuthService (`src/services/AuthService.ts`)
**Purpose**: Authentication operations
**Methods**:
- `login(credentials)` - User authentication
- `resetPassword(orgId, userId, country)` - Password reset
- `activateUser(orgId, userId, country)` - User activation

**Integration**: HTTP client with axios, error handling

### 2. ContentService (`src/services/ContentService.ts`)
**Purpose**: Dynamic content management
**Methods**:
- `getBanner(country, language)` - Banner content
- `getBackgroundImage(country, language)` - Background images
- `getAnnouncement(country, language)` - Announcements
- `getLoginEndpoint(country)` - Dynamic endpoints

### 3. ConfigService (`src/services/ConfigService.ts`)
**Purpose**: Configuration management
**Methods**:
- `getLinks()` - External links
- `getContactInfo(country)` - Contact information
- `getBlockAccessEndpoint(country)` - API endpoints

## UI Component Library

### Shadcn/UI Components Used:
- `Button` - Primary actions
- `Input` - Form inputs
- `Select` - Dropdowns
- `Dialog` - Modal interfaces
- `Alert` - Notifications
- `Card` - Content containers
- `Label` - Form labels
- `Progress` - Loading indicators
- `RadioGroup` - Option selection
- `Accordion` - Collapsible content

## State Management Strategy

### Local Component State:
- Form inputs and validation
- UI visibility states
- Loading states

### Shared State:
- Country and language preferences (via StorageUtils)
- Authentication status
- Dynamic content

### Persistence:
- LocalStorage for user preferences
- Session management for authentication

## Responsive Design

### Breakpoints:
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

### Layout Strategy:
- Flexbox for component layout
- CSS Grid for complex layouts
- Tailwind responsive utilities

## Performance Considerations

### Code Splitting:
- Page-level splitting via React Router
- Lazy loading for heavy components

### Optimization:
- React.memo for expensive components
- Callback memoization with useCallback
- Effect dependency optimization

## Testing Strategy

### Component Testing:
- Jest and React Testing Library
- Accessibility testing
- User interaction testing

### Integration Testing:
- API integration tests
- E2E user workflows

## Accessibility

### Standards:
- WCAG 2.1 AA compliance
- Keyboard navigation
- Screen reader support
- Semantic HTML

### Implementation:
- ARIA labels and roles
- Focus management
- Color contrast compliance
