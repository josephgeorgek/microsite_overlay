
# MFE-BFO-Landing Application

## Overview
This is a micro frontend (MFE) business banking login application built with React, TypeScript, and MUI. It provides a responsive login interface with multi-language support and various user assistance features.

## Features
- Multi-language support (English/Chinese)
- Multi-country support (SG, MY, HK, ID, CN, VN, TH)
- Responsive design for mobile to desktop
- Interactive help dialogs and wizards
- Content fetching with fallback mechanisms
- Comprehensive test coverage

## Technology Stack
- React 18 with TypeScript
- Material-UI (MUI) for component library
- Vite for build tooling
- Jest for testing
- Axios for HTTP requests

## Getting Started

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Installation
```bash
npm install
```

### Development
```bash
npm run dev
```

### Testing
```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage
```

### Build
```bash
npm run build
```

## Testing Guide

### Running Tests
The application uses Jest and React Testing Library for testing. Tests are located in the `src/__tests__` directory.

**Available test commands:**
- `npm test` - Run all tests once
- `npm run test:watch` - Run tests in watch mode (reruns on file changes)
- `npm run test:coverage` - Run tests with coverage report

### Test Structure
- Unit tests for individual components
- Integration tests for user workflows
- Accessibility tests for compliance

### Example Test Run
```bash
npm test
```

Expected output:
```
 PASS  src/__tests__/Index.test.tsx
  Index Page
    ✓ renders welcome title
    ✓ renders login form fields
    ✓ opens need help dialog when clicked
    ✓ toggles password visibility
    ✓ switches language

Test Suites: 1 passed, 1 total
Tests:       5 passed, 5 total
```

## Architecture

The application follows a modular architecture with:
- **Components**: Reusable UI components
- **Pages**: Route-level components
- **Services**: API and business logic
- **Types**: TypeScript type definitions
