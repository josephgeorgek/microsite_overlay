
# Architecture Diagrams

## Component Diagram

```plantuml
@startuml Component Diagram

package "Pages" {
  [Index Page] as IndexPage
  [NotFound Page] as NotFoundPage
}

package "Components" {
  [BankLogo]
  [CountrySelector]
  [LanguageToggle]
  [NeedHelpDialog]
  [NewUserWizard]
  [ResetPasswordWizard]
}

package "Services" {
  [ContentService]
  [AuthService]
}

IndexPage --> BankLogo : uses
IndexPage --> CountrySelector : uses
IndexPage --> LanguageToggle : uses
IndexPage --> NeedHelpDialog : uses
IndexPage --> NewUserWizard : uses
IndexPage --> ResetPasswordWizard : uses
IndexPage --> ContentService : calls
IndexPage --> AuthService : calls

@enduml
```

## Sequence Diagram

```plantuml
@startuml Login Flow

actor User
participant "Index Page" as IndexPage
participant "AuthService" as Auth
participant "ContentService" as Content
database "Backend API" as API

User -> IndexPage : Visits landing page
activate IndexPage

IndexPage -> Content : getAnnouncement(country, language)
Content -> API : GET /api/content/announcement
API --> Content : Return announcement data
Content --> IndexPage : Return announcement data

IndexPage -> Content : getBanner(country, language)
Content -> API : GET /api/content/banner
API --> Content : Return banner data
Content --> IndexPage : Return banner data

IndexPage --> User : Display login form

User -> IndexPage : Enter credentials & click Login
IndexPage -> Auth : login(organizationId, userId, password)
activate Auth

Auth -> API : POST /api/auth/login
activate API

alt Successful Login
  API --> Auth : Return success & tokens
  Auth --> IndexPage : Return success
  IndexPage --> User : Redirect to dashboard
else Invalid Credentials
  API --> Auth : Return error
  Auth --> IndexPage : Return error
  IndexPage --> User : Show error message
else Network Error
  API -> Auth : Connection error
  Auth --> IndexPage : Return error
  IndexPage --> User : Show network error
end

deactivate API
deactivate Auth
deactivate IndexPage

@enduml
```

## Swimlane Diagram

```plantuml
@startuml User Authentication Flow

|User|
start
:Visit Login Page;

|Frontend|
:Load Login Form;
:Fetch Announcements;
:Fetch Banner;
:Display Login UI;

|User|
:Enter Organization ID;
:Enter User ID;
:Enter Password;
:Click Login Button;

|Frontend|
:Validate Form Fields;

if (All Fields Valid?) then (yes)
  :Show Loading State;
  
  |Authentication Service|
  :Process Login Request;
  :Send Credentials to API;
  
  |Backend API|
  :Validate Credentials;
  :Check Account Status;
  
  if (Credentials Valid?) then (yes)
    if (Account Active?) then (yes)
      :Generate Auth Token;
      :Return Success Response;
      
      |Authentication Service|
      :Store Auth Token;
      :Return Login Success;
      
      |Frontend|
      :Hide Loading State;
      :Redirect to Dashboard;
      
      |User|
      :View Dashboard;
      
    else (no)
      :Return Account Locked Error;
      
      |Authentication Service|
      :Return Account Status Error;
      
      |Frontend|
      :Hide Loading State;
      :Show Account Locked Message;
      :Display Reset Options;
      
      |User|
      :Click Reset Password;
      
      |Frontend|
      :Open Reset Wizard;
      stop
    endif
  else (no)
    :Return Invalid Credentials Error;
    
    |Authentication Service|
    :Return Authentication Error;
    
    |Frontend|
    :Hide Loading State;
    :Show Error Message;
    :Clear Password Field;
    
    |User|
    :Retry Login;
    stop
  endif
else (no)
  :Show Field Validation Errors;
  
  |User|
  :Fix Input Errors;
endif

stop

@enduml
```

