
import AuthService from '../services/AuthService';
import axios from 'axios';

// Mock axios
jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('AuthService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('login', () => {
    it('should successfully login with valid credentials', async () => {
      const mockResponse = {
        data: {
          success: true,
          message: 'Login successful',
          token: 'mock-jwt-token',
          country: 'SG'
        }
      };
      
      mockedAxios.post.mockResolvedValueOnce(mockResponse);
      
      const credentials = {
        organizationId: 'ACME001',
        userId: 'user1',
        password: 'password123',
        country: 'SG'
      };
      
      const result = await AuthService.login(credentials);
      
      expect(result.success).toBe(true);
      expect(result.token).toBe('mock-jwt-token');
      expect(mockedAxios.post).toHaveBeenCalledWith(
        'http://localhost:8080/sg/customer-security-corp/v1/orguserid-login',
        {
          organisationId: 'ACME001',
          userId: 'user1',
          password: 'password123'
        },
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );
    });

    it('should handle login failure with invalid credentials', async () => {
      const mockError = {
        response: {
          status: 401,
          data: {
            success: false,
            message: 'Invalid credentials'
          }
        }
      };
      
      mockedAxios.post.mockRejectedValueOnce(mockError);
      
      const credentials = {
        organizationId: 'INVALID',
        userId: 'invalid',
        password: 'wrong',
        country: 'SG'
      };
      
      await expect(AuthService.login(credentials)).rejects.toEqual(mockError);
    });

    it('should handle blocked user scenario', async () => {
      const mockResponse = {
        data: {
          success: false,
          message: 'User is blocked',
          token: null,
          country: 'SG'
        }
      };
      
      mockedAxios.post.mockResolvedValueOnce(mockResponse);
      
      const credentials = {
        organizationId: 'ACME001',
        userId: 'blockeduser',
        password: 'password123',
        country: 'SG'
      };
      
      const result = await AuthService.login(credentials);
      
      expect(result.success).toBe(false);
      expect(result.message).toBe('User is blocked');
    });
  });

  describe('resetPassword', () => {
    it('should successfully initiate password reset', async () => {
      const mockResponse = {
        data: {
          status: 'success',
          message: 'Password reset initiated'
        }
      };
      
      mockedAxios.post.mockResolvedValueOnce(mockResponse);
      
      const result = await AuthService.resetPassword('ACME001', 'user1', 'SG');
      
      expect(result.status).toBe('success');
      expect(mockedAxios.post).toHaveBeenCalledWith(
        'http://localhost:8080/sg/password-reset',
        { organizationId: 'ACME001', userId: 'user1' }
      );
    });

    it('should handle user not found for password reset', async () => {
      const mockError = {
        response: {
          status: 404,
          data: {
            status: 'failed',
            message: 'User not found'
          }
        }
      };
      
      mockedAxios.post.mockRejectedValueOnce(mockError);
      
      await expect(AuthService.resetPassword('INVALID', 'invalid', 'SG')).rejects.toEqual(mockError);
    });
  });

  describe('activateUser', () => {
    it('should successfully initiate user activation', async () => {
      const mockResponse = {
        data: {
          status: 'success',
          message: 'User activation initiated'
        }
      };
      
      mockedAxios.post.mockResolvedValueOnce(mockResponse);
      
      const result = await AuthService.activateUser('ACME001', 'newuser', 'MY');
      
      expect(result.status).toBe('success');
      expect(mockedAxios.post).toHaveBeenCalledWith(
        'http://localhost:8080/my/user-activation',
        { organizationId: 'ACME001', userId: 'newuser' }
      );
    });
  });
});
