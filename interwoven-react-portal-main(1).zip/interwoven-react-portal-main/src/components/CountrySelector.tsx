
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface CountrySelectorProps {
  value: string;
  onChange: (value: string) => void;
}

const countries = [
  { code: 'SG', name: 'Singapore', flag: '🇸🇬' },
  { code: 'MY', name: 'Malaysia', flag: '🇲🇾' },
  { code: 'HK', name: 'Hong Kong', flag: '🇭🇰' },
  { code: 'ID', name: 'Indonesia', flag: '🇮🇩' },
  { code: 'CN', name: 'China', flag: '🇨🇳' },
  { code: 'VN', name: 'Vietnam', flag: '🇻🇳' },
  { code: 'TH', name: 'Thailand', flag: '🇹🇭' },
];

const CountrySelector: React.FC<CountrySelectorProps> = ({ value, onChange }) => {
  const selectedCountry = countries.find(c => c.code === value);

  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-28 h-8 text-xs border border-gray-300 bg-white">
        <SelectValue>
          <div className="flex items-center gap-1">
            <span className="text-base leading-none">{selectedCountry?.flag || '🏳️'}</span>
            <span className="font-medium">{selectedCountry?.code}</span>
          </div>
        </SelectValue>
      </SelectTrigger>
      <SelectContent className="bg-white border border-gray-200 shadow-lg">
        {countries.map((country) => (
          <SelectItem key={country.code} value={country.code}>
            <div className="flex items-center gap-2">
              <span className="text-base leading-none">{country.flag}</span>
              <span className="text-sm">{country.name}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default CountrySelector;
