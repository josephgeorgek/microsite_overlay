
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { X, Check, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import BankLogo from './BankLogo';

interface NewUserWizardProps {
  open: boolean;
  onClose: () => void;
  language: string;
}

const NewUserWizard: React.FC<NewUserWizardProps> = ({ open, onClose, language }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [organizationId, setOrganizationId] = useState('');
  const [userId, setUserId] = useState('');
  const [otpValue, setOtpValue] = useState('');
  const [otpError, setOtpError] = useState('');
  const [otpTimer, setOtpTimer] = useState(58);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [hardwareTokenSerial, setHardwareTokenSerial] = useState('');
  const [hardwareTokenCode, setHardwareTokenCode] = useState('');

  const texts = {
    en: {
      title: 'ACTIVATE ACCESS',
      subtitle: 'Enter your login credentials',
      description: 'When you open your account, we will send a unique Organisation ID and User ID to your email address in our records. Please check your inbox.',
      organizationId: 'Organisation ID',
      userId: 'User ID',
      back: 'Back',
      next: 'Next',
      steps: ['Enter login credentials', 'Verify number', 'Set up password', 'Activate hardware token'],
      verifyNumber: 'Verify number',
      otpDescription: 'Enter the 6-digit SMS One-Time Password (OTP) sent to +65 ****1234.',
      requestNewOtp: 'Request new OTP in',
      notYourNumber: 'Not your number? Give us the correct one by completing and mailing us the',
      applyForm: '"Apply and Manage OCBC Velocity" form',
      updateRecords: 'We will update our records within 7 working days of receiving the form.',
      setupPassword: 'Set up password',
      password: 'Password',
      reenterPassword: 'Re-enter password',
      mustContain: 'Must contain or be:',
      passwordRules: [
        '8 to 12 characters',
        '1 uppercase and 1 lowercase letter',
        '2 numeric characters',
        '1 special character',
        'Not identical to Organisation ID or User ID'
      ],
      activateHardwareToken: 'Activate hardware token',
      serialNumber: 'Enter the serial number at the back of the hardware token.',
      step1Desc: 'STEP 1',
      step2Desc: 'STEP 2',
      step3Desc: 'STEP 3',
      generateOtp: 'Press [•] button to generate a One-Time Password.',
      enterCode: 'Enter the 8-digit code shown on the hardware token.',
      requestSuccessful: 'Request successful',
      activationMessage: 'Your access has been activated. Use your new password to log in to business online banking.',
      backToLogin: 'Back to Login'
    },
    zh: {
      title: '激活访问',
      subtitle: '输入您的登录凭据',
      description: '当您开设账户时，我们会将唯一的机构ID和用户ID发送到我们记录中的电子邮件地址。请检查您的收件箱。',
      organizationId: '机构编号',
      userId: '用户编号',
      back: '返回',
      next: '下一步',
      steps: ['输入登录凭据', '验证号码', '设置密码', '激活硬件令牌'],
      verifyNumber: '验证号码',
      otpDescription: '输入发送到+65 ****1234的6位SMS一次性密码(OTP)。',
      requestNewOtp: '重新申请OTP在',
      notYourNumber: '不是您的号码？请填写并邮寄给我们',
      applyForm: '"申请和管理OCBC Velocity"表格',
      updateRecords: '我们将在收到表格后7个工作日内更新我们的记录。',
      setupPassword: '设置密码',
      password: '密码',
      reenterPassword: '重新输入密码',
      mustContain: '必须包含或为：',
      passwordRules: [
        '8至12个字符',
        '1个大写字母和1个小写字母',
        '2个数字字符',
        '1个特殊字符',
        '不能与机构ID或用户ID相同'
      ],
      activateHardwareToken: '激活硬件令牌',
      serialNumber: '输入硬件令牌背面的序列号。',
      step1Desc: '步骤1',
      step2Desc: '步骤2',
      step3Desc: '步骤3',
      generateOtp: '按[•]按钮生成一次性密码。',
      enterCode: '输入硬件令牌上显示的8位数代码。',
      requestSuccessful: '请求成功',
      activationMessage: '您的访问已激活。使用您的新密码登录企业网上银行。',
      backToLogin: '返回登录'
    }
  };

  const currentTexts = texts[language] || texts.en;

  const validatePassword = (pwd: string) => {
    const rules = [
      { test: pwd.length >= 8 && pwd.length <= 12, message: '8 to 12 characters' },
      { test: /[A-Z]/.test(pwd) && /[a-z]/.test(pwd), message: '1 uppercase and 1 lowercase letter' },
      { test: (pwd.match(/\d/g) || []).length >= 2, message: '2 numeric characters' },
      { test: /[!@#$%^&*(),.?":{}|<>]/.test(pwd), message: '1 special character' },
      { test: pwd !== organizationId && pwd !== userId, message: 'Not identical to Organisation ID or User ID' }
    ];
    
    return rules;
  };

  const handleNext = () => {
    if (activeStep === 0) {
      // No validation for step 1, just proceed
      setActiveStep(activeStep + 1);
      return;
    }
    
    if (activeStep === 1) {
      if (otpValue.length !== 6) {
        setOtpError('OTP does not match what we have sent.');
        return;
      }
      setOtpError('');
    }
    
    if (activeStep === 2) {
      if (password !== confirmPassword) {
        setPasswordError('Passwords do not match');
        return;
      }
      const passwordRules = validatePassword(password);
      const failedRules = passwordRules.filter(rule => !rule.test);
      if (failedRules.length > 0) {
        setPasswordError('Password does not meet requirements');
        return;
      }
      setPasswordError('');
    }
    
    if (activeStep < 4) {
      setActiveStep(activeStep + 1);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">{currentTexts.subtitle}</h2>
            <p className="text-gray-600 mb-6">{currentTexts.description}</p>
            
            <div className="grid grid-cols-2 gap-6 mb-6">
              <div>
                <Label htmlFor="org-id" className="block text-sm font-medium mb-2">
                  {currentTexts.organizationId}
                </Label>
                <Input
                  id="org-id"
                  value={organizationId}
                  onChange={(e) => setOrganizationId(e.target.value)}
                  placeholder="EsolAlpha"
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="user-id" className="block text-sm font-medium mb-2">
                  {currentTexts.userId}
                </Label>
                <Input
                  id="user-id"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder="PeterAlpha"
                  className="w-full"
                />
              </div>
            </div>
          </div>
        );
        
      case 1:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">{currentTexts.verifyNumber}</h2>
            <p className="text-gray-600 mb-8">{currentTexts.otpDescription}</p>
            
            <div className="flex justify-center mb-6">
              <InputOTP
                maxLength={6}
                value={otpValue}
                onChange={(value) => setOtpValue(value)}
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>
            
            {otpError && (
              <Alert className="border-red-200 bg-red-50 mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-red-800">
                  {otpError}
                </AlertDescription>
              </Alert>
            )}
            
            <p className="text-sm text-gray-600 mb-4">
              {currentTexts.requestNewOtp} 00:{otpTimer.toString().padStart(2, '0')}
            </p>
            
            <p className="text-sm text-gray-600">
              {currentTexts.notYourNumber}{' '}
              <a href="#" className="text-blue-600 hover:underline">
                {currentTexts.applyForm}
              </a>
              . {currentTexts.updateRecords}
            </p>
          </div>
        );
        
      case 2:
        const passwordRules = validatePassword(password);
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-6">{currentTexts.setupPassword}</h2>
            
            <div className="space-y-6 mb-6">
              <div>
                <Label htmlFor="password" className="block text-sm font-medium mb-2">
                  {currentTexts.password}
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              
              <div>
                <Label htmlFor="confirm-password" className="block text-sm font-medium mb-2">
                  {currentTexts.reenterPassword}
                </Label>
                <div className="relative">
                  <Input
                    id="confirm-password"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <p className="text-sm font-medium mb-3">{currentTexts.mustContain}</p>
              <div className="space-y-2">
                {passwordRules.map((rule, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Check className={`h-4 w-4 ${rule.test ? 'text-green-600' : 'text-gray-400'}`} />
                    <span className={`text-sm ${rule.test ? 'text-green-600' : 'text-gray-600'}`}>
                      {currentTexts.passwordRules[index]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            
            {passwordError && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-red-800">
                  {passwordError}
                </AlertDescription>
              </Alert>
            )}
          </div>
        );
        
      case 3:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-6">{currentTexts.activateHardwareToken}</h2>
            
            <div className="space-y-8">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 bg-gray-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                    1
                  </div>
                  <span className="text-sm font-medium">{currentTexts.step1Desc}</span>
                </div>
                <p className="text-sm text-gray-600 mb-4 ml-8">{currentTexts.serialNumber}</p>
                <div className="ml-8">
                  <Input
                    value={hardwareTokenSerial}
                    onChange={(e) => setHardwareTokenSerial(e.target.value)}
                    placeholder=""
                    className="w-full max-w-md"
                  />
                </div>
                <div className="ml-8 mt-4 flex justify-center">
                  <div className="w-20 h-32 bg-gray-200 rounded border flex items-end justify-center pb-2">
                    <span className="text-xs text-gray-600">12345</span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                    2
                  </div>
                  <span className="text-sm font-medium">{currentTexts.step2Desc}</span>
                </div>
                <p className="text-sm text-gray-600 mb-4 ml-8">{currentTexts.generateOtp}</p>
                <div className="ml-8 flex justify-center">
                  <div className="w-24 h-16 bg-gray-200 rounded border flex flex-col items-center justify-center">
                    <div className="w-3 h-3 bg-red-500 rounded-full mb-1"></div>
                    <span className="text-xs text-gray-600">•</span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 bg-gray-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                    3
                  </div>
                  <span className="text-sm font-medium">{currentTexts.step3Desc}</span>
                </div>
                <p className="text-sm text-gray-600 mb-4 ml-8">{currentTexts.enterCode}</p>
                <div className="ml-8">
                  <Input
                    value={hardwareTokenCode}
                    onChange={(e) => setHardwareTokenCode(e.target.value)}
                    placeholder=""
                    className="w-full max-w-md"
                  />
                </div>
                <div className="ml-8 mt-4 flex justify-center">
                  <div className="w-24 h-12 bg-gray-800 rounded border flex items-center justify-center">
                    <span className="text-green-400 text-xs font-mono">12345678</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
        
      case 4:
        return (
          <div className="flex-1 p-8 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-xl font-semibold mb-4">{currentTexts.requestSuccessful}</h2>
            <p className="text-gray-600 mb-8 max-w-md">{currentTexts.activationMessage}</p>
            <Button
              onClick={onClose}
              className="bg-gray-600 hover:bg-gray-700 px-8"
            >
              {currentTexts.backToLogin}
            </Button>
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh] p-0 gap-0 font-sans [&>button]:hidden">
        <DialogHeader className="bg-white border-l-4 border-l-red-600 p-6 flex flex-row items-center justify-between">
          <div className="flex items-center gap-4">
            <BankLogo />
            <DialogTitle className="text-lg font-semibold">{currentTexts.title}</DialogTitle>
          </div>
          <Button 
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-gray-600 hover:bg-gray-100"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="flex flex-1">
          <div className="w-80 bg-gray-50 border-r border-gray-200 p-6">
            <div className="space-y-0 relative">
              {currentTexts.steps.map((step, index) => (
                <div key={index} className="relative">
                  <div className="flex items-center space-x-3 py-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium relative z-10 ${
                      index < activeStep 
                        ? 'bg-green-600 text-white' 
                        : index === activeStep 
                        ? 'bg-red-600 text-white' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {index < activeStep ? <Check className="h-4 w-4" /> : index + 1}
                    </div>
                    <span className={`text-sm ${
                      index <= activeStep ? 'text-gray-900 font-medium' : 'text-gray-500'
                    }`}>
                      {step}
                    </span>
                  </div>
                  
                  {index < currentTexts.steps.length - 1 && (
                    <div className="absolute left-4 top-12 w-0.5 h-8 bg-gray-300"></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 flex flex-col">
            {renderStepContent()}
            
            {activeStep < 4 && (
              <div className="border-t border-gray-200 p-6 flex justify-between bg-gray-50">
                <Button 
                  onClick={handleBack}
                  disabled={activeStep === 0}
                  variant="outline"
                  className="px-6"
                >
                  {currentTexts.back}
                </Button>
                <Button 
                  onClick={handleNext}
                  className="bg-red-600 hover:bg-red-700 px-6"
                >
                  {currentTexts.next}
                </Button>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NewUserWizard;
