
import AppConfig from '../config/AppConfig';

class ProxyService {
  private static readonly PROXY_ENDPOINTS = {
    securityNotice: '/api/security-notice',
    needHelpContent: '/api/need-help-content'
  };

  static async fetchSecurityNotice(): Promise<string> {
    try {
      const config = AppConfig.getSecurityNoticeConfig();
      
      // Direct fetch - will require CORS to be configured on the target server
      // or a local proxy server to handle the requests
      const response = await fetch(config.announcementUrl, {
        method: 'GET',
        headers: {
          'Accept': 'text/plain,text/html,*/*',
          'Cache-Control': 'no-cache'
        },
        mode: 'cors'
      });

      if (response.ok) {
        const textContent = await response.text();
        return textContent.trim();
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Failed to fetch security notice (CORS or network error):', error);
      console.log('Consider setting up a local proxy server or configuring CORS on the target server');
      throw error;
    }
  }

  static async fetchNeedHelpContent(): Promise<string> {
    try {
      const config = AppConfig.getNeedHelpConfig();
      
      // Direct fetch - will require CORS to be configured on the target server
      // or a local proxy server to handle the requests
      const response = await fetch(config.contentUrl, {
        method: 'GET',
        headers: {
          'Accept': 'text/plain,text/html,*/*',
          'Cache-Control': 'no-cache'
        },
        mode: 'cors'
      });

      if (response.ok) {
        const textContent = await response.text();
        return textContent.trim();
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Failed to fetch Need Help content (CORS or network error):', error);
      console.log('Consider setting up a local proxy server or configuring CORS on the target server');
      throw error;
    }
  }
}

export default ProxyService;
