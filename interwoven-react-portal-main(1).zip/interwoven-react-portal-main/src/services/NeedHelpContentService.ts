
import ProxyService from './ProxyService';

class NeedHelpContentService {
  private static instance: NeedHelpContentService;
  private cachedContent: string | null = null;
  private lastFetchTime: number = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  public static getInstance(): NeedHelpContentService {
    if (!NeedHelpContentService.instance) {
      NeedHelpContentService.instance = new NeedHelpContentService();
    }
    return NeedHelpContentService.instance;
  }

  async getNeedHelpContent(): Promise<string> {
    const now = Date.now();
    
    // Return cached content if it's still valid
    if (this.cachedContent && (now - this.lastFetchTime) < this.CACHE_DURATION) {
      return this.cachedContent;
    }

    try {
      console.log('Fetching Need Help content from external URL...');
      const textContent = await ProxyService.fetchNeedHelpContent();
      
      if (textContent && textContent.length > 0) {
        this.cachedContent = textContent;
        this.lastFetchTime = now;
        console.log('Successfully fetched Need Help content');
        return textContent;
      }
    } catch (error) {
      console.warn('Failed to fetch Need Help content from external URL:', error);
    }

    // Return empty string as fallback
    console.log('Using empty fallback for Need Help content');
    return '';
  }

  // Method to force refresh the cache
  refreshCache(): void {
    this.cachedContent = null;
    this.lastFetchTime = 0;
  }
}

export default NeedHelpContentService;
