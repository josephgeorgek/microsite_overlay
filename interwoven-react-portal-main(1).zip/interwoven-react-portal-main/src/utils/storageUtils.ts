
const COUNTRY_KEY = 'bank_selected_country';
const LANGUAGE_KEY = 'bank_selected_language';

export const StorageUtils = {
  setCountry: (country: string) => {
    localStorage.setItem(COUNTRY_KEY, country);
  },

  getCountry: (): string => {
    return localStorage.getItem(COUNTRY_KEY) || 'SG';
  },

  setLanguage: (language: string) => {
    localStorage.setItem(LANGUAGE_KEY, language);
  },

  getLanguage: (): string => {
    return localStorage.getItem(LANGUAGE_KEY) || 'en';
  }
};
